﻿using System;

namespace $safeprojectname$
{
    public interface ITimeProvider
    {
        DateTime GetUtcTime();
    }
}
