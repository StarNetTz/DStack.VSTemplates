﻿namespace $safeprojectname$
{
    public class LookupItem
    {
        public string Id { get; set; }
        public string Value { get; set; }
    }
}
