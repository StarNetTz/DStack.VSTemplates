﻿using $ext_projectname$.Common;
namespace $safeprojectname$
{
    public class Organization
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public Address Address { get; set; }
    }
}
