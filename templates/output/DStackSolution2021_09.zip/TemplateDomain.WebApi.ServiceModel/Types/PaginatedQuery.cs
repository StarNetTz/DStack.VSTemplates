﻿namespace $safeprojectname$
{
    public class PaginatedQuery
    {
        public int CurrentPage { get; set; }
        public int PageSize { get; set; } = 1;
    }
}
